const questions = [
    {
        question: "Quem pintou a Mona Lisa?",
        options: ["Leonardo da Vinci", "Pablo Picasso", "Vincent van Gogh"],
        answer: "Leonardo da Vinci"
    },
    {
        question: "Qual é o maior oceano do mundo?",
        options: ["Oceano Atlântico", "Oceano Pacífico", "Oceano Índico"],
        answer: "Oceano Pacífico"
    },
    {
        question: "Qual é o maior deserto do mundo?",
        options: ["Deserto do Saara", "Deserto de Atacama", "Deserto de Gobi"],
        answer: "Deserto do Saara"
    },
    {
        question: "Quem escreveu 'Dom Quixote'?",
        options: ["Miguel de Cervantes", "Gabriel García Márquez", "Fyodor Dostoevsky"],
        answer: "Miguel de Cervantes"
    },
    {
        question: "Qual é a maior ilha do mundo?",
        options: ["Ilha de Java", "Ilha de Bali", "Ilha da Groenlândia"],
        answer: "Ilha da Groenlândia"
    },
    {
        question: "Qual é o elemento químico mais abundante na crosta terrestre?",
        options: ["Oxigênio", "Silício", "Alumínio"],
        answer: "Silício"
    },
    {
        question: "Qual é a moeda oficial do Japão?",
        options: ["Yen", "Dólar", "Euro"],
        answer: "Yen"
    },
    {
        question: "Qual é a capital da Austrália?",
        options: ["Sydney", "Melbourne", "Camberra"],
        answer: "Camberra"
    },
    {
        question: "Quem foi o primeiro homem a pisar na lua?",
        options: ["Neil Armstrong", "Buzz Aldrin", "Yuri Gagarin"],
        answer: "Neil Armstrong"
    },
    {
        question: "Qual é o maior animal marinho?",
        options: ["Baleia-azul", "Tubarão-branco", "Orca"],
        answer: "Baleia-azul"
    },
    {
        question: "Quantos lados tem um triângulo?",
        options: ["3", "4", "5"],
        answer: "3"
    },
    {
        question: "Qual é o planeta conhecido como 'Planeta Vermelho'?",
        options: ["Vênus", "Marte", "Urano"],
        answer: "Marte"
    },
    {
        question: "Em que ano a Segunda Guerra Mundial começou?",
        options: ["1939", "1941", "1945"],
        answer: "1939"
    },
    {
        question: "Qual é a capital da Rússia?",
        options: ["São Petersburgo", "Moscou", "Kiev"],
        answer: "Moscou"
    },
    {
        question: "Quem é o autor de 'O Senhor dos Anéis'?",
        options: ["J.K. Rowling", "George R.R. Martin", "J.R.R. Tolkien"],
        answer: "J.R.R. Tolkien"
    },
    {
        question: "Quantos planetas existem no sistema solar?",
        options: ["7", "8", "9"],
        answer: "8"
    },
    {
        question: "Qual é o maior planeta do sistema solar?",
        options: ["Terra", "Vênus", "Júpiter"],
        answer: "Júpiter"
    },
    {
        question: "Quem escreveu a peça 'Romeu e Julieta'?",
        options: ["Charles Dickens", "Jane Austen", "William Shakespeare"],
        answer: "William Shakespeare"
    }
];

let currentQuestion = 0;
let score = 0;

const questionElement = document.querySelector('section div');
const optionsElement = document.querySelector('.options');
const scoreElement = document.getElementById('score');
const footerElement = document.querySelector('footer');

function showQuestion() {
    const current = questions[currentQuestion];
    questionElement.textContent = current.question;
    optionsElement.innerHTML = "";

    current.options.forEach((option, index) => {
        const button = document.createElement("button");
        button.textContent = option;
        button.classList.add("option");
        button.addEventListener("click", () => checkAnswer(option));
        optionsElement.appendChild(button);
    });

    const backButtonContainer = document.querySelector('.backButtonContainer'); // Adicione esta linha

    // Exibe o botão "Voltar" somente a partir da segunda pergunta
    if (currentQuestion > 0) {
        backButtonContainer.style.display = "block";
    } else {
        backButtonContainer.style.display = "none";
    }
}



function checkAnswer(selectedOption) {
    const current = questions[currentQuestion];
    if (selectedOption === current.answer) {
        score++;
    }
    currentQuestion++;

    if (currentQuestion < questions.length) {
        showQuestion();
    } else {
        endQuiz();
    }
    updateScore();
}

const backButton = document.getElementById('backButton');
backButton.addEventListener('click', goBack);

function goBack() {
    if (currentQuestion > 0) {
        currentQuestion--;
        showQuestion();
        updateScore();
    }
}


function updateScore() {
    scoreElement.textContent = `Pontuação: ${score} de ${questions.length}`;
}

function endQuiz() {
    questionElement.textContent = "Quiz concluído!";
    optionsElement.innerHTML = "";
    footerElement.innerHTML = "&copy; João_Lindão";
}

showQuestion();
updateScore();
